import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TrataSenhaComponent } from './trata-senha.component';

describe('TrataSenhaComponent', () => {
  let component: TrataSenhaComponent;
  let fixture: ComponentFixture<TrataSenhaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TrataSenhaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TrataSenhaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
