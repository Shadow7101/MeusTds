import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-trata-senha',
  templateUrl: './trata-senha.component.html',
  styleUrls: ['./trata-senha.component.css']
})
export class TrataSenhaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
